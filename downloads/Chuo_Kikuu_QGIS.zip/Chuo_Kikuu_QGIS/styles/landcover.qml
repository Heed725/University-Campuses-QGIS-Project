<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis minScale="100000000" simplifyLocal="1" readOnly="0" hasScaleBasedVisibilityFlag="0" labelsEnabled="0" simplifyAlgorithm="0" simplifyDrawingHints="1" maxScale="0" styleCategories="AllStyleCategories" symbologyReferenceScale="-1" version="3.34.4-Prizren" simplifyDrawingTol="1" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal enabled="0" startExpression="" durationUnit="min" limitMode="0" startField="" mode="0" endField="" endExpression="" durationField="" fixedDuration="0" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zscale="1" clamping="Terrain" type="IndividualFeatures" zoffset="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" binding="Centroid" symbology="Line" extrusionEnabled="0" extrusion="0">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol is_animated="0" type="line" frame_rate="10" clip_to_extent="1" alpha="1" name="" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{2baa4398-13bb-484c-aada-d562660d8295}" class="SimpleLine" pass="0" locked="0">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="214,21,198,255" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol is_animated="0" type="fill" frame_rate="10" clip_to_extent="1" alpha="1" name="" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{cb9de8f5-0d18-43f4-b3a8-aab9d850f635}" class="SimpleFill" pass="0" locked="0">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="214,21,198,255" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="153,15,141,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol is_animated="0" type="marker" frame_rate="10" clip_to_extent="1" alpha="1" name="" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{10ad9bb1-5a8f-4b3a-9144-ad8383ec1ab2}" class="SimpleMarker" pass="0" locked="0">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="214,21,198,255" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="diamond" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="153,15,141,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="3" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 symbollevels="0" referencescale="-1" forceraster="0" type="singleSymbol" enableorderby="0">
    <symbols>
      <symbol is_animated="0" type="fill" frame_rate="10" clip_to_extent="1" alpha="1" name="0" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" id="{1d506239-2e25-4589-845a-66a7f93edbd1}" class="SimpleFill" pass="0" locked="0">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="201,218,183,255" type="QString" name="color"/>
            <Option value="round" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="183,202,166,255" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.1" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option value="" type="QString"/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="fid" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="osm_id" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="name" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="map_label" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="category" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="group_name" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="osm_url" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="snapshot" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="inside_osm_university" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="tags_json" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="building" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="amenity" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="highway" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="surface" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="access" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="operator" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="religion" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="leisure" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="natural" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="landuse" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="waterway" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="building_levels" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="area_m2" configurationFlags="NoFlag">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" name="" index="0"/>
    <alias field="osm_id" name="" index="1"/>
    <alias field="name" name="" index="2"/>
    <alias field="map_label" name="" index="3"/>
    <alias field="category" name="" index="4"/>
    <alias field="group_name" name="" index="5"/>
    <alias field="osm_url" name="" index="6"/>
    <alias field="snapshot" name="" index="7"/>
    <alias field="inside_osm_university" name="" index="8"/>
    <alias field="tags_json" name="" index="9"/>
    <alias field="building" name="" index="10"/>
    <alias field="amenity" name="" index="11"/>
    <alias field="highway" name="" index="12"/>
    <alias field="surface" name="" index="13"/>
    <alias field="access" name="" index="14"/>
    <alias field="operator" name="" index="15"/>
    <alias field="religion" name="" index="16"/>
    <alias field="leisure" name="" index="17"/>
    <alias field="natural" name="" index="18"/>
    <alias field="landuse" name="" index="19"/>
    <alias field="waterway" name="" index="20"/>
    <alias field="building_levels" name="" index="21"/>
    <alias field="area_m2" name="" index="22"/>
  </aliases>
  <splitPolicies>
    <policy field="fid" policy="Duplicate"/>
    <policy field="osm_id" policy="Duplicate"/>
    <policy field="name" policy="Duplicate"/>
    <policy field="map_label" policy="Duplicate"/>
    <policy field="category" policy="Duplicate"/>
    <policy field="group_name" policy="Duplicate"/>
    <policy field="osm_url" policy="Duplicate"/>
    <policy field="snapshot" policy="Duplicate"/>
    <policy field="inside_osm_university" policy="Duplicate"/>
    <policy field="tags_json" policy="Duplicate"/>
    <policy field="building" policy="Duplicate"/>
    <policy field="amenity" policy="Duplicate"/>
    <policy field="highway" policy="Duplicate"/>
    <policy field="surface" policy="Duplicate"/>
    <policy field="access" policy="Duplicate"/>
    <policy field="operator" policy="Duplicate"/>
    <policy field="religion" policy="Duplicate"/>
    <policy field="leisure" policy="Duplicate"/>
    <policy field="natural" policy="Duplicate"/>
    <policy field="landuse" policy="Duplicate"/>
    <policy field="waterway" policy="Duplicate"/>
    <policy field="building_levels" policy="Duplicate"/>
    <policy field="area_m2" policy="Duplicate"/>
  </splitPolicies>
  <defaults>
    <default applyOnUpdate="0" expression="" field="fid"/>
    <default applyOnUpdate="0" expression="" field="osm_id"/>
    <default applyOnUpdate="0" expression="" field="name"/>
    <default applyOnUpdate="0" expression="" field="map_label"/>
    <default applyOnUpdate="0" expression="" field="category"/>
    <default applyOnUpdate="0" expression="" field="group_name"/>
    <default applyOnUpdate="0" expression="" field="osm_url"/>
    <default applyOnUpdate="0" expression="" field="snapshot"/>
    <default applyOnUpdate="0" expression="" field="inside_osm_university"/>
    <default applyOnUpdate="0" expression="" field="tags_json"/>
    <default applyOnUpdate="0" expression="" field="building"/>
    <default applyOnUpdate="0" expression="" field="amenity"/>
    <default applyOnUpdate="0" expression="" field="highway"/>
    <default applyOnUpdate="0" expression="" field="surface"/>
    <default applyOnUpdate="0" expression="" field="access"/>
    <default applyOnUpdate="0" expression="" field="operator"/>
    <default applyOnUpdate="0" expression="" field="religion"/>
    <default applyOnUpdate="0" expression="" field="leisure"/>
    <default applyOnUpdate="0" expression="" field="natural"/>
    <default applyOnUpdate="0" expression="" field="landuse"/>
    <default applyOnUpdate="0" expression="" field="waterway"/>
    <default applyOnUpdate="0" expression="" field="building_levels"/>
    <default applyOnUpdate="0" expression="" field="area_m2"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" unique_strength="1" field="fid" notnull_strength="1" constraints="3"/>
    <constraint exp_strength="0" unique_strength="0" field="osm_id" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="name" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="map_label" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="category" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="group_name" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="osm_url" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="snapshot" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="inside_osm_university" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="tags_json" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="building" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="amenity" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="highway" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="surface" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="access" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="operator" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="religion" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="leisure" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="natural" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="landuse" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="waterway" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="building_levels" notnull_strength="0" constraints="0"/>
    <constraint exp_strength="0" unique_strength="0" field="area_m2" notnull_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="osm_id"/>
    <constraint exp="" desc="" field="name"/>
    <constraint exp="" desc="" field="map_label"/>
    <constraint exp="" desc="" field="category"/>
    <constraint exp="" desc="" field="group_name"/>
    <constraint exp="" desc="" field="osm_url"/>
    <constraint exp="" desc="" field="snapshot"/>
    <constraint exp="" desc="" field="inside_osm_university"/>
    <constraint exp="" desc="" field="tags_json"/>
    <constraint exp="" desc="" field="building"/>
    <constraint exp="" desc="" field="amenity"/>
    <constraint exp="" desc="" field="highway"/>
    <constraint exp="" desc="" field="surface"/>
    <constraint exp="" desc="" field="access"/>
    <constraint exp="" desc="" field="operator"/>
    <constraint exp="" desc="" field="religion"/>
    <constraint exp="" desc="" field="leisure"/>
    <constraint exp="" desc="" field="natural"/>
    <constraint exp="" desc="" field="landuse"/>
    <constraint exp="" desc="" field="waterway"/>
    <constraint exp="" desc="" field="building_levels"/>
    <constraint exp="" desc="" field="area_m2"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>coalesce(nullif("name",''),"category")</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>

# Chuo Kikuu — full administrative area

## Open the QGIS project

1. Extract the ZIP into a normal folder.
2. Open **Chuo_Kikuu.qgz** in QGIS 3.34 or newer, including QGIS 3.40.
3. Keep the `data` folder beside the project. The packaged vector map works offline.

The project opens on the **entire Chuo Kikuu administrative boundary**, OpenStreetMap relation **5608085**, approximately **5.03 km²**. It includes the UDSM Mlimani main campus and surrounding mapped areas. The separate OSM university footprint is retained in the **OPTIONAL** group and is switched off initially.

## Included layers

- Full Chuo Kikuu administrative boundary.
- 1,213 building footprints, grouped by mapped building use.
- 356 road and path features.
- 134 amenities, grouped into education, food, banking, health, transport, community, housing, administration and water/sanitation.
- 36 green-space polygons and 8 sports polygons.
- 235 stream/drainage features.
- 10 mapped gates/entrances and 19 bus-stop/transport point records.
- Optional UDSM OSM university footprint.
- Optional online OpenStreetMap basemap.

These counts describe the full administrative study area, not a university asset register. Nearby facilities are included according to geography; no UDSM affiliation is inferred.

## Editing and exporting

- Tick a layer to show/hide it.
- Double-click Buildings, Roads & paths or Facilities & amenities → **Symbology** to edit category colours.
- Open the facilities attribute table to search `name`, `category` or `group_name`. Full OSM names and source links are also in `Facilities.csv`.
- Zoom in for more facility labels, building names, gates and bus stops. QGIS suppresses colliding labels. Unnamed features remain unnamed.
- Open **Project → Layouts → Chuo Kikuu • full area map** to export the A3 map as PDF or PNG.
- The exported map and a canvas preview are in `maps/`.
- Use the **Full Chuo Kikuu overview** spatial bookmark to return to the complete boundary.
- Expand OPTIONAL and tick the university footprint if you want to compare it with the administrative area.
- Expand BASEMAP and tick OpenStreetMap for online tiles. Internet is needed for that layer only. Toggle the overlying vector layers as needed.

## Data formats

`data/chuo_kikuu.gpkg` contains all ten editable vector layers in **EPSG:32737 — WGS 84 / UTM zone 37S**. `area_m2` and `length_m` fields store planar areas and lengths in metric units. GeoJSON copies are in **EPSG:4326**. Reusable `.qml` styles are in `styles/`.

Project paths are relative. Move the entire extracted folder together. No additional plugin is required.

## Source dates and boundary meaning

Feature snapshot: **2 October 2026**, preserved OpenStreetMap extract from `Heed725/UDSM_Campus_Explorer`, commit `a038a9d6bab53913b73b8d37ddb8816d308b2e9c`.

Administrative and university boundary features: retrieved **11 October 2026** from the OpenStreetMap API.

Chuo Kikuu is an administrative subward. Its boundary is not a university ownership boundary. The optional university outline is also an OSM map feature, not a cadastral survey, and its completeness has not been independently verified.

Roads and drainage are clipped to the administrative boundary. Buildings are included by interior representative point, so edge footprints can extend slightly beyond the outline. Area amenities are represented by interior points. OSM records can be missing, unnamed or duplicated; transport records may represent opposite sides of a road. Mapped vegetation is not a new landcover survey. No DEM, flood assessment or routing is included.

## Attribution

Geographic data **© OpenStreetMap contributors**, **ODbL 1.0**. Adapted data retains that licence.

- https://www.openstreetmap.org/relation/5608085
- https://www.openstreetmap.org/way/798357475
- https://github.com/Heed725/UDSM_Campus_Explorer
- https://www.openstreetmap.org/copyright
- https://opendatacommons.org/licenses/odbl/1-0/

Independent map; not an official UDSM or local-government publication.

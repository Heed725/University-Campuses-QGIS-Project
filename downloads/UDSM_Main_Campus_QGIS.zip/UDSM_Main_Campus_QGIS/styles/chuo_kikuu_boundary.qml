<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="0" simplifyMaxScale="1" maxScale="0" simplifyDrawingHints="1" styleCategories="AllStyleCategories" hasScaleBasedVisibilityFlag="0" simplifyLocal="1" symbologyReferenceScale="-1" readOnly="0" simplifyAlgorithm="0" version="3.34.4-Prizren" minScale="100000000" simplifyDrawingTol="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal enabled="0" startField="" mode="0" limitMode="0" endField="" startExpression="" accumulate="0" durationField="" endExpression="" fixedDuration="0" durationUnit="min">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusion="0" type="IndividualFeatures" clamping="Terrain" binding="Centroid" zoffset="0" zscale="1" showMarkerSymbolInSurfacePlots="0" extrusionEnabled="0" respectLayerSymbol="1" symbology="Line">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" alpha="1" name="" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" locked="0" id="{60eedeaa-83a6-42bb-be71-d5b7acd5543e}" pass="0">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="30,240,139,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.6" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol force_rhr="0" type="fill" clip_to_extent="1" alpha="1" name="" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleFill" locked="0" id="{e95bdc19-2a27-4ee2-930f-98d95675ca5c}" pass="0">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="30,240,139,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="22,171,99,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol force_rhr="0" type="marker" clip_to_extent="1" alpha="1" name="" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleMarker" locked="0" id="{f0524736-93f6-4c88-908f-d41a65c548c0}" pass="0">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="30,240,139,255" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="diamond" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="22,171,99,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="3" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 symbollevels="0" type="singleSymbol" enableorderby="0" forceraster="0" referencescale="-1">
    <symbols>
      <symbol force_rhr="0" type="fill" clip_to_extent="1" alpha="1" name="0" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleFill" locked="0" id="{086f047f-6019-4d95-85cd-cba1270a39c5}" pass="0">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="236,239,226,110" name="color"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="37,79,75,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.7" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks type="StringList">
      <Option type="QString" value=""/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="map_label">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="category">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="group_name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_url">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="snapshot">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="inside_osm_university">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tags_json">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="building">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="amenity">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="highway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="surface">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="access">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="operator">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="religion">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="leisure">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="natural">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="landuse">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="waterway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="building_levels">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="area_m2">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="osm_id" index="1" name=""/>
    <alias field="name" index="2" name=""/>
    <alias field="map_label" index="3" name=""/>
    <alias field="category" index="4" name=""/>
    <alias field="group_name" index="5" name=""/>
    <alias field="osm_url" index="6" name=""/>
    <alias field="snapshot" index="7" name=""/>
    <alias field="inside_osm_university" index="8" name=""/>
    <alias field="tags_json" index="9" name=""/>
    <alias field="building" index="10" name=""/>
    <alias field="amenity" index="11" name=""/>
    <alias field="highway" index="12" name=""/>
    <alias field="surface" index="13" name=""/>
    <alias field="access" index="14" name=""/>
    <alias field="operator" index="15" name=""/>
    <alias field="religion" index="16" name=""/>
    <alias field="leisure" index="17" name=""/>
    <alias field="natural" index="18" name=""/>
    <alias field="landuse" index="19" name=""/>
    <alias field="waterway" index="20" name=""/>
    <alias field="building_levels" index="21" name=""/>
    <alias field="area_m2" index="22" name=""/>
  </aliases>
  <splitPolicies>
    <policy field="fid" policy="Duplicate"/>
    <policy field="osm_id" policy="Duplicate"/>
    <policy field="name" policy="Duplicate"/>
    <policy field="map_label" policy="Duplicate"/>
    <policy field="category" policy="Duplicate"/>
    <policy field="group_name" policy="Duplicate"/>
    <policy field="osm_url" policy="Duplicate"/>
    <policy field="snapshot" policy="Duplicate"/>
    <policy field="inside_osm_university" policy="Duplicate"/>
    <policy field="tags_json" policy="Duplicate"/>
    <policy field="building" policy="Duplicate"/>
    <policy field="amenity" policy="Duplicate"/>
    <policy field="highway" policy="Duplicate"/>
    <policy field="surface" policy="Duplicate"/>
    <policy field="access" policy="Duplicate"/>
    <policy field="operator" policy="Duplicate"/>
    <policy field="religion" policy="Duplicate"/>
    <policy field="leisure" policy="Duplicate"/>
    <policy field="natural" policy="Duplicate"/>
    <policy field="landuse" policy="Duplicate"/>
    <policy field="waterway" policy="Duplicate"/>
    <policy field="building_levels" policy="Duplicate"/>
    <policy field="area_m2" policy="Duplicate"/>
  </splitPolicies>
  <defaults>
    <default expression="" field="fid" applyOnUpdate="0"/>
    <default expression="" field="osm_id" applyOnUpdate="0"/>
    <default expression="" field="name" applyOnUpdate="0"/>
    <default expression="" field="map_label" applyOnUpdate="0"/>
    <default expression="" field="category" applyOnUpdate="0"/>
    <default expression="" field="group_name" applyOnUpdate="0"/>
    <default expression="" field="osm_url" applyOnUpdate="0"/>
    <default expression="" field="snapshot" applyOnUpdate="0"/>
    <default expression="" field="inside_osm_university" applyOnUpdate="0"/>
    <default expression="" field="tags_json" applyOnUpdate="0"/>
    <default expression="" field="building" applyOnUpdate="0"/>
    <default expression="" field="amenity" applyOnUpdate="0"/>
    <default expression="" field="highway" applyOnUpdate="0"/>
    <default expression="" field="surface" applyOnUpdate="0"/>
    <default expression="" field="access" applyOnUpdate="0"/>
    <default expression="" field="operator" applyOnUpdate="0"/>
    <default expression="" field="religion" applyOnUpdate="0"/>
    <default expression="" field="leisure" applyOnUpdate="0"/>
    <default expression="" field="natural" applyOnUpdate="0"/>
    <default expression="" field="landuse" applyOnUpdate="0"/>
    <default expression="" field="waterway" applyOnUpdate="0"/>
    <default expression="" field="building_levels" applyOnUpdate="0"/>
    <default expression="" field="area_m2" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="fid" notnull_strength="1" unique_strength="1" constraints="3" exp_strength="0"/>
    <constraint field="osm_id" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="name" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="map_label" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="category" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="group_name" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="osm_url" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="snapshot" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="inside_osm_university" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="tags_json" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="building" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="amenity" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="highway" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="surface" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="access" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="operator" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="religion" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="leisure" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="natural" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="landuse" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="waterway" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="building_levels" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
    <constraint field="area_m2" notnull_strength="0" unique_strength="0" constraints="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="fid" exp="" desc=""/>
    <constraint field="osm_id" exp="" desc=""/>
    <constraint field="name" exp="" desc=""/>
    <constraint field="map_label" exp="" desc=""/>
    <constraint field="category" exp="" desc=""/>
    <constraint field="group_name" exp="" desc=""/>
    <constraint field="osm_url" exp="" desc=""/>
    <constraint field="snapshot" exp="" desc=""/>
    <constraint field="inside_osm_university" exp="" desc=""/>
    <constraint field="tags_json" exp="" desc=""/>
    <constraint field="building" exp="" desc=""/>
    <constraint field="amenity" exp="" desc=""/>
    <constraint field="highway" exp="" desc=""/>
    <constraint field="surface" exp="" desc=""/>
    <constraint field="access" exp="" desc=""/>
    <constraint field="operator" exp="" desc=""/>
    <constraint field="religion" exp="" desc=""/>
    <constraint field="leisure" exp="" desc=""/>
    <constraint field="natural" exp="" desc=""/>
    <constraint field="landuse" exp="" desc=""/>
    <constraint field="waterway" exp="" desc=""/>
    <constraint field="building_levels" exp="" desc=""/>
    <constraint field="area_m2" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig sortExpression="" sortOrder="0" actionWidgetStyle="dropDown">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>coalesce(nullif("name",''),"category")</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>

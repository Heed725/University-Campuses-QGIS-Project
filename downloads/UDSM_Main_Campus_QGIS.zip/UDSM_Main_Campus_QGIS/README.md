# University of Dar es Salaam — Mlimani Main Campus

## Open the map

1. Extract this ZIP into a normal folder. Do not open the project while it is still inside the ZIP.
2. Open **UDSM_Main_Campus.qgz** in QGIS 3.34 or newer (including QGIS 3.40). This shows the full Chuo Kikuu administrative area.
3. Open **UDSM_Campus_Detail.qgz** for a closer view of the mapped university footprint and main campus facilities.

Keep the `data` folder beside both project files. All project paths are relative, so you can move the extracted folder to another computer. Packaged vector layers work offline. No plugin installation is needed.

## What is included

- Two ready-to-open QGIS projects with editable symbols, labels and layers.
- One editable GeoPackage: `data/udsm_campus.gpkg`, in **EPSG:32737 — WGS 84 / UTM zone 37S**. Distances and areas are in metres and square metres.
- GeoJSON copies in **EPSG:4326 — WGS 84**, including both boundary polygons.
- Buildings, roads and paths, amenities, green spaces, sports areas, streams/drainage, gates and bus stops.
- Reusable QGIS styles in `styles/`.
- `Facilities.csv`, including full names, categories, source IDs and direct OSM links.
- Two A3 landscape print layouts in each project, with a north arrow, scale bar, legend and source note.
- Exported map previews in `maps/`.

## The two boundaries are different

**Chuo Kikuu administrative boundary** is OpenStreetMap relation **5608085**. The map uses it for the full study area, approximately 5.03 km². It contains UDSM and other nearby facilities and residential areas. A feature being inside Chuo Kikuu does not establish that UDSM owns or operates it.

**UDSM OSM university footprint** is OpenStreetMap way **798357475**. It is shown as a separate gold dashed outline. This mapped footprint covers approximately 0.65 km² and does not establish the full university estate. Its completeness has not been independently verified.

Neither outline is a surveyed or legal university ownership boundary. For land administration, replace the OSM outline with an approved UDSM survey/cadastral boundary.

## Change the map

- **Show or hide a layer:** tick its box in the Layers panel.
- **Change colours:** double-click a layer → Symbology. Buildings, roads and amenities use editable category colours.
- **Read a feature:** use Identify Features, then click a building, road or facility. Full OSM tags are preserved in `tags_json`.
- **Find facilities:** right-click Facilities & amenities → Open Attribute Table. Search or filter the `name`, `category` or `group_name` fields.
- **Filter facilities within the OSM university footprint:** use `"inside_osm_university" = 1`. This is a spatial classification only, based on a representative point; it does not prove university ownership or affiliation.
- **See more labels:** zoom in. All named facilities label below approximately 1:7,500; building names below approximately 1:5,500. Some labels are hidden to avoid collisions. Unnamed objects remain unnamed.
- **Show gates and bus stops:** zoom below approximately 1:8,500.
- **Return to a saved view:** View → Panels → Spatial Bookmarks, then select either campus bookmark.
- **Use the online OSM background:** expand BASEMAP and tick OpenStreetMap. Internet is required for tiles. Buildings, vegetation and other vector layers overlay it; hide individual layers to expose more of the basemap.

## Export a map

1. Open **Project → Layouts**.
2. Select **01 • Chuo Kikuu campus overview** or **02 • UDSM main campus detail**.
3. Use **Layout → Export as PDF** or **Export as Image**.

The layouts preserve their own map view and styles. If you change the map styling and want those changes in a layout, select its map item and update/unlock its layer styles under Item Properties.

## Data date and limitations

Feature snapshot: **2 October 2026**. Source: the preserved OpenStreetMap extract in `Heed725/UDSM_Campus_Explorer`, repository commit `a038a9d6bab53913b73b8d37ddb8816d308b2e9c`.

Both boundary features were retrieved separately from the OpenStreetMap API on **11 October 2026**. The Chuo Kikuu boundary matched the study area in the snapshot.

Study-area records: **1,213 buildings**, **356 road/path features**, **134 amenities**, **36 green-space polygons**, **8 sports polygons**, **235 stream/drainage features**, **10 gates/entrances**, and **19 bus-stop/transport point records**. These counts cover the entire Chuo Kikuu study area, not just UDSM assets. Separate point records can represent the same facility or opposite sides of a road. Counts are not an official asset inventory.

Road and drainage geometries are clipped to Chuo Kikuu. Buildings are included when their representative point is covered by Chuo Kikuu; edge footprints can extend slightly across the boundary. Amenities derived from areas use an interior representative point. Missing names, buildings, paths or facilities reflect gaps in OSM mapping. Landcover is the mapped OSM classification, not a newly surveyed or satellite-derived assessment. No DEM, flood assessment or navigation routing is included.

The empty water-polygon GeoJSON records that no water polygon was extracted; watercourses are in the streams/drainage layer.

Generated and reopened with QGIS **3.34.4**; compatible project format for QGIS **3.40**. Online tile availability depends on your connection.

## Attribution and sources

Geographic data **© OpenStreetMap contributors**, licensed under **Open Database License (ODbL) 1.0**. Adapted geographic layers retain that licence.

- https://www.openstreetmap.org/relation/5608085
- https://www.openstreetmap.org/way/798357475
- https://github.com/Heed725/UDSM_Campus_Explorer
- https://www.openstreetmap.org/copyright
- https://opendatacommons.org/licenses/odbl/1-0/
- https://www.udsm.ac.tz/map

This is an independent campus map, not an official UDSM publication.

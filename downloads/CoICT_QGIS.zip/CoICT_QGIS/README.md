# CoICT — University of Dar es Salaam
## Kijitonyama campus QGIS map

### Open the map

1. Extract the ZIP into a normal folder.
2. Open **CoICT_Kijitonyama.qgz** in QGIS 3.34 or newer, including QGIS 3.40.
3. Keep the `data` folder beside the project.

All packaged vector layers work offline. No plugin is needed. The optional OpenStreetMap tile basemap requires internet.

### Contents

- CoICT campus outline: OpenStreetMap **way 478260661**.
- **26 mapped building footprint records**, with the available block and facility names.
- **11 road and path features**.
- **8 facility records**, including mapped education, coworking, hostel, food, parking and sanitation features.
- **2 sports polygons**.
- **1 nearby bus-stop record**.
- Editable GeoPackage, GeoJSON copies, reusable QGIS styles and `Facilities.csv`.
- One A3 landscape map layout with north arrow, 100-metre scale bar, legend and attribution.
- Printable map preview and canvas preview in `maps/`.
- Original downloaded OpenStreetMap extracts, gzip-compressed, in `source/`.

The outline measures approximately **7.21 hectares** in UTM zone 37S. This measures the OSM polygon, not an independently verified estate.

### Edit or export

- Tick layers to show/hide them.
- Double-click a layer → **Symbology** to change colours.
- Open Buildings or Facilities & amenities → **Open Attribute Table** to search by `name`, `category` or `group_name`.
- Original OSM names are preserved in `name`; `map_label` can be edited independently for cartography. Unnamed buildings remain unnamed.
- Use Identify Features to inspect tags and follow the `osm_url` source link. Full tags are in `tags_json`.
- Open **Project → Layouts → CoICT • Kijitonyama campus map** to export PDF or PNG.
- The layout keeps its own layer styles. To apply later style edits, select the map item and update/unlock its saved styles in Item Properties.
- Expand BASEMAP and tick OpenStreetMap for online context.

`data/coict_campus.gpkg` contains six editable vector layers in **EPSG:32737 — WGS 84 / UTM zone 37S**. `area_m2` and `length_m` use metric units. GeoJSON copies are **EPSG:4326**. All paths are relative, so move the extracted folder together.

### Sources and limitations

The boundary and campus extract were retrieved from the OpenStreetMap API on **11 October 2026**. This project uses the **Kijitonyama campus**, identified in CoICT's official campus-life and contact information.

The outline is an OSM campus feature, not a surveyed property boundary. Buildings are selected by interior representative point; some edge footprints extend beyond the outline. Roads and sports polygons are clipped to the outline. Facilities mapped as areas are represented by interior points. Transport points are included within or approximately 17 metres of the boundary using a 0.00015-degree geographic tolerance.

Counts refer to OSM records, not an official asset inventory. Some mapped footprints overlap, including similarly named blocks; all original records are preserved. Missing labels, duplicate facilities and naming/spelling differences can exist. Hostel classification uses the mapped hostel tag even where the generic building tag differs.

No vegetation polygons, waterways or gate points were found under the extraction rules, so no empty layers or invented features are added. The named building **coict gate** remains in the buildings layer. Sports geometry alone does not establish university ownership or access. No DEM, flood assessment or routing is included.

Independent map; not an official university publication.

### Attribution

Geographic data **© OpenStreetMap contributors**, licensed under **ODbL 1.0**. Adapted geographic layers retain that licence.

- https://www.openstreetmap.org/way/478260661
- https://www.openstreetmap.org/copyright
- https://opendatacommons.org/licenses/odbl/1-0/
- https://coict.udsm.ac.tz/about/campus-life

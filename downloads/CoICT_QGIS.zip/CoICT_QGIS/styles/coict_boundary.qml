<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis labelsEnabled="0" simplifyAlgorithm="0" maxScale="0" minScale="100000000" simplifyDrawingHints="1" simplifyMaxScale="1" simplifyLocal="1" symbologyReferenceScale="-1" simplifyDrawingTol="1" version="3.34.4-Prizren" styleCategories="AllStyleCategories" hasScaleBasedVisibilityFlag="0" readOnly="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal limitMode="0" fixedDuration="0" startField="" enabled="0" endField="" durationField="" accumulate="0" endExpression="" startExpression="" durationUnit="min" mode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation symbology="Line" clamping="Terrain" zscale="1" respectLayerSymbol="1" zoffset="0" type="IndividualFeatures" binding="Centroid" extrusionEnabled="0" showMarkerSymbolInSurfacePlots="0" extrusion="0">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" force_rhr="0" type="line" is_animated="0" frame_rate="10" clip_to_extent="1" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" pass="0" id="{23de5660-68b9-432a-9a56-e00fd82bccb0}" class="SimpleLine">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="163,118,205,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.6" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10" clip_to_extent="1" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" pass="0" id="{d9120408-792e-44aa-8c1b-b05e72f01b87}" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="163,118,205,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="116,84,146,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" force_rhr="0" type="marker" is_animated="0" frame_rate="10" clip_to_extent="1" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" pass="0" id="{eeaef1f2-951b-4a62-ab83-a34c8e7b0cec}" class="SimpleMarker">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="163,118,205,255" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="diamond" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="116,84,146,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="3" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="singleSymbol" symbollevels="0" forceraster="0" enableorderby="0" referencescale="-1">
    <symbols>
      <symbol alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10" clip_to_extent="1" name="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" enabled="1" pass="0" id="{00e61675-2996-4fd8-a0b8-7b1a40e4654b}" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="236,239,226,110" name="color"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="37,79,75,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.7" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option type="QString" value=""/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="map_label">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="category">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="group_name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_url">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="snapshot">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="inside_osm_campus">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tags_json">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="building">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="amenity">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="highway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="surface">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="access">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="operator">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="religion">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="leisure">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="natural">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="landuse">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="waterway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tourism">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="office">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="shop">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="building_levels">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="area_m2">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="osm_id" index="1" name=""/>
    <alias field="name" index="2" name=""/>
    <alias field="map_label" index="3" name=""/>
    <alias field="category" index="4" name=""/>
    <alias field="group_name" index="5" name=""/>
    <alias field="osm_url" index="6" name=""/>
    <alias field="snapshot" index="7" name=""/>
    <alias field="inside_osm_campus" index="8" name=""/>
    <alias field="tags_json" index="9" name=""/>
    <alias field="building" index="10" name=""/>
    <alias field="amenity" index="11" name=""/>
    <alias field="highway" index="12" name=""/>
    <alias field="surface" index="13" name=""/>
    <alias field="access" index="14" name=""/>
    <alias field="operator" index="15" name=""/>
    <alias field="religion" index="16" name=""/>
    <alias field="leisure" index="17" name=""/>
    <alias field="natural" index="18" name=""/>
    <alias field="landuse" index="19" name=""/>
    <alias field="waterway" index="20" name=""/>
    <alias field="tourism" index="21" name=""/>
    <alias field="office" index="22" name=""/>
    <alias field="shop" index="23" name=""/>
    <alias field="building_levels" index="24" name=""/>
    <alias field="area_m2" index="25" name=""/>
  </aliases>
  <splitPolicies>
    <policy field="fid" policy="Duplicate"/>
    <policy field="osm_id" policy="Duplicate"/>
    <policy field="name" policy="Duplicate"/>
    <policy field="map_label" policy="Duplicate"/>
    <policy field="category" policy="Duplicate"/>
    <policy field="group_name" policy="Duplicate"/>
    <policy field="osm_url" policy="Duplicate"/>
    <policy field="snapshot" policy="Duplicate"/>
    <policy field="inside_osm_campus" policy="Duplicate"/>
    <policy field="tags_json" policy="Duplicate"/>
    <policy field="building" policy="Duplicate"/>
    <policy field="amenity" policy="Duplicate"/>
    <policy field="highway" policy="Duplicate"/>
    <policy field="surface" policy="Duplicate"/>
    <policy field="access" policy="Duplicate"/>
    <policy field="operator" policy="Duplicate"/>
    <policy field="religion" policy="Duplicate"/>
    <policy field="leisure" policy="Duplicate"/>
    <policy field="natural" policy="Duplicate"/>
    <policy field="landuse" policy="Duplicate"/>
    <policy field="waterway" policy="Duplicate"/>
    <policy field="tourism" policy="Duplicate"/>
    <policy field="office" policy="Duplicate"/>
    <policy field="shop" policy="Duplicate"/>
    <policy field="building_levels" policy="Duplicate"/>
    <policy field="area_m2" policy="Duplicate"/>
  </splitPolicies>
  <defaults>
    <default applyOnUpdate="0" field="fid" expression=""/>
    <default applyOnUpdate="0" field="osm_id" expression=""/>
    <default applyOnUpdate="0" field="name" expression=""/>
    <default applyOnUpdate="0" field="map_label" expression=""/>
    <default applyOnUpdate="0" field="category" expression=""/>
    <default applyOnUpdate="0" field="group_name" expression=""/>
    <default applyOnUpdate="0" field="osm_url" expression=""/>
    <default applyOnUpdate="0" field="snapshot" expression=""/>
    <default applyOnUpdate="0" field="inside_osm_campus" expression=""/>
    <default applyOnUpdate="0" field="tags_json" expression=""/>
    <default applyOnUpdate="0" field="building" expression=""/>
    <default applyOnUpdate="0" field="amenity" expression=""/>
    <default applyOnUpdate="0" field="highway" expression=""/>
    <default applyOnUpdate="0" field="surface" expression=""/>
    <default applyOnUpdate="0" field="access" expression=""/>
    <default applyOnUpdate="0" field="operator" expression=""/>
    <default applyOnUpdate="0" field="religion" expression=""/>
    <default applyOnUpdate="0" field="leisure" expression=""/>
    <default applyOnUpdate="0" field="natural" expression=""/>
    <default applyOnUpdate="0" field="landuse" expression=""/>
    <default applyOnUpdate="0" field="waterway" expression=""/>
    <default applyOnUpdate="0" field="tourism" expression=""/>
    <default applyOnUpdate="0" field="office" expression=""/>
    <default applyOnUpdate="0" field="shop" expression=""/>
    <default applyOnUpdate="0" field="building_levels" expression=""/>
    <default applyOnUpdate="0" field="area_m2" expression=""/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" field="fid" constraints="3" unique_strength="1" notnull_strength="1"/>
    <constraint exp_strength="0" field="osm_id" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="name" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="map_label" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="category" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="group_name" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="osm_url" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="snapshot" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="inside_osm_campus" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="tags_json" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="building" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="amenity" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="highway" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="surface" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="access" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="operator" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="religion" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="leisure" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="natural" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="landuse" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="waterway" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="tourism" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="office" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="shop" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="building_levels" constraints="0" unique_strength="0" notnull_strength="0"/>
    <constraint exp_strength="0" field="area_m2" constraints="0" unique_strength="0" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="fid" exp="" desc=""/>
    <constraint field="osm_id" exp="" desc=""/>
    <constraint field="name" exp="" desc=""/>
    <constraint field="map_label" exp="" desc=""/>
    <constraint field="category" exp="" desc=""/>
    <constraint field="group_name" exp="" desc=""/>
    <constraint field="osm_url" exp="" desc=""/>
    <constraint field="snapshot" exp="" desc=""/>
    <constraint field="inside_osm_campus" exp="" desc=""/>
    <constraint field="tags_json" exp="" desc=""/>
    <constraint field="building" exp="" desc=""/>
    <constraint field="amenity" exp="" desc=""/>
    <constraint field="highway" exp="" desc=""/>
    <constraint field="surface" exp="" desc=""/>
    <constraint field="access" exp="" desc=""/>
    <constraint field="operator" exp="" desc=""/>
    <constraint field="religion" exp="" desc=""/>
    <constraint field="leisure" exp="" desc=""/>
    <constraint field="natural" exp="" desc=""/>
    <constraint field="landuse" exp="" desc=""/>
    <constraint field="waterway" exp="" desc=""/>
    <constraint field="tourism" exp="" desc=""/>
    <constraint field="office" exp="" desc=""/>
    <constraint field="shop" exp="" desc=""/>
    <constraint field="building_levels" exp="" desc=""/>
    <constraint field="area_m2" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>coalesce(nullif("name",''),"category")</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>

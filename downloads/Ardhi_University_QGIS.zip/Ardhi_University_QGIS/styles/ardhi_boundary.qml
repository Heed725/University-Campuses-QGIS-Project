<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis styleCategories="AllStyleCategories" simplifyAlgorithm="0" symbologyReferenceScale="-1" hasScaleBasedVisibilityFlag="0" readOnly="0" minScale="100000000" simplifyDrawingTol="1" labelsEnabled="0" version="3.34.4-Prizren" simplifyLocal="1" maxScale="0" simplifyDrawingHints="1" simplifyMaxScale="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal startExpression="" mode="0" fixedDuration="0" durationUnit="min" enabled="0" endField="" startField="" endExpression="" durationField="" accumulate="0" limitMode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation respectLayerSymbol="1" zoffset="0" clamping="Terrain" showMarkerSymbolInSurfacePlots="0" type="IndividualFeatures" extrusion="0" binding="Centroid" zscale="1" symbology="Line" extrusionEnabled="0">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol force_rhr="0" type="line" name="" is_animated="0" alpha="1" frame_rate="10" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" class="SimpleLine" locked="0" id="{eeb75488-26ea-451a-8804-d0e93bf29078}">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="185,114,127,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.6" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol force_rhr="0" type="fill" name="" is_animated="0" alpha="1" frame_rate="10" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" class="SimpleFill" locked="0" id="{f9e11cb2-816d-4757-9805-e7d40bd9859d}">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="185,114,127,255" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="132,81,91,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol force_rhr="0" type="marker" name="" is_animated="0" alpha="1" frame_rate="10" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" class="SimpleMarker" locked="0" id="{7c4f7c29-ffdb-4025-8056-8ad42ca75337}">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="185,114,127,255" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="diamond" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="132,81,91,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="3" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" referencescale="-1" forceraster="0" type="singleSymbol" symbollevels="0">
    <symbols>
      <symbol force_rhr="0" type="fill" name="0" is_animated="0" alpha="1" frame_rate="10" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" enabled="1" class="SimpleFill" locked="0" id="{5f2d72b6-c368-4ebb-bc9a-9637e54a4e74}">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="236,239,226,110" name="color"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="37,79,75,255" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.7" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option type="QString" value=""/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="map_label">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="category">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="group_name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_url">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="snapshot">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="inside_osm_campus">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tags_json">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="building">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="amenity">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="highway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="surface">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="access">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="operator">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="religion">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="leisure">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="natural">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="landuse">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="waterway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tourism">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="office">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="shop">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="building_levels">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="area_m2">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" name="" index="0"/>
    <alias field="osm_id" name="" index="1"/>
    <alias field="name" name="" index="2"/>
    <alias field="map_label" name="" index="3"/>
    <alias field="category" name="" index="4"/>
    <alias field="group_name" name="" index="5"/>
    <alias field="osm_url" name="" index="6"/>
    <alias field="snapshot" name="" index="7"/>
    <alias field="inside_osm_campus" name="" index="8"/>
    <alias field="tags_json" name="" index="9"/>
    <alias field="building" name="" index="10"/>
    <alias field="amenity" name="" index="11"/>
    <alias field="highway" name="" index="12"/>
    <alias field="surface" name="" index="13"/>
    <alias field="access" name="" index="14"/>
    <alias field="operator" name="" index="15"/>
    <alias field="religion" name="" index="16"/>
    <alias field="leisure" name="" index="17"/>
    <alias field="natural" name="" index="18"/>
    <alias field="landuse" name="" index="19"/>
    <alias field="waterway" name="" index="20"/>
    <alias field="tourism" name="" index="21"/>
    <alias field="office" name="" index="22"/>
    <alias field="shop" name="" index="23"/>
    <alias field="building_levels" name="" index="24"/>
    <alias field="area_m2" name="" index="25"/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="osm_id"/>
    <policy policy="Duplicate" field="name"/>
    <policy policy="Duplicate" field="map_label"/>
    <policy policy="Duplicate" field="category"/>
    <policy policy="Duplicate" field="group_name"/>
    <policy policy="Duplicate" field="osm_url"/>
    <policy policy="Duplicate" field="snapshot"/>
    <policy policy="Duplicate" field="inside_osm_campus"/>
    <policy policy="Duplicate" field="tags_json"/>
    <policy policy="Duplicate" field="building"/>
    <policy policy="Duplicate" field="amenity"/>
    <policy policy="Duplicate" field="highway"/>
    <policy policy="Duplicate" field="surface"/>
    <policy policy="Duplicate" field="access"/>
    <policy policy="Duplicate" field="operator"/>
    <policy policy="Duplicate" field="religion"/>
    <policy policy="Duplicate" field="leisure"/>
    <policy policy="Duplicate" field="natural"/>
    <policy policy="Duplicate" field="landuse"/>
    <policy policy="Duplicate" field="waterway"/>
    <policy policy="Duplicate" field="tourism"/>
    <policy policy="Duplicate" field="office"/>
    <policy policy="Duplicate" field="shop"/>
    <policy policy="Duplicate" field="building_levels"/>
    <policy policy="Duplicate" field="area_m2"/>
  </splitPolicies>
  <defaults>
    <default expression="" field="fid" applyOnUpdate="0"/>
    <default expression="" field="osm_id" applyOnUpdate="0"/>
    <default expression="" field="name" applyOnUpdate="0"/>
    <default expression="" field="map_label" applyOnUpdate="0"/>
    <default expression="" field="category" applyOnUpdate="0"/>
    <default expression="" field="group_name" applyOnUpdate="0"/>
    <default expression="" field="osm_url" applyOnUpdate="0"/>
    <default expression="" field="snapshot" applyOnUpdate="0"/>
    <default expression="" field="inside_osm_campus" applyOnUpdate="0"/>
    <default expression="" field="tags_json" applyOnUpdate="0"/>
    <default expression="" field="building" applyOnUpdate="0"/>
    <default expression="" field="amenity" applyOnUpdate="0"/>
    <default expression="" field="highway" applyOnUpdate="0"/>
    <default expression="" field="surface" applyOnUpdate="0"/>
    <default expression="" field="access" applyOnUpdate="0"/>
    <default expression="" field="operator" applyOnUpdate="0"/>
    <default expression="" field="religion" applyOnUpdate="0"/>
    <default expression="" field="leisure" applyOnUpdate="0"/>
    <default expression="" field="natural" applyOnUpdate="0"/>
    <default expression="" field="landuse" applyOnUpdate="0"/>
    <default expression="" field="waterway" applyOnUpdate="0"/>
    <default expression="" field="tourism" applyOnUpdate="0"/>
    <default expression="" field="office" applyOnUpdate="0"/>
    <default expression="" field="shop" applyOnUpdate="0"/>
    <default expression="" field="building_levels" applyOnUpdate="0"/>
    <default expression="" field="area_m2" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" unique_strength="1" constraints="3" field="fid" notnull_strength="1"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="osm_id" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="name" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="map_label" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="category" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="group_name" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="osm_url" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="snapshot" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="inside_osm_campus" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="tags_json" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="building" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="amenity" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="highway" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="surface" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="access" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="operator" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="religion" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="leisure" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="natural" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="landuse" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="waterway" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="tourism" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="office" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="shop" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="building_levels" notnull_strength="0"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" field="area_m2" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="fid" desc="" exp=""/>
    <constraint field="osm_id" desc="" exp=""/>
    <constraint field="name" desc="" exp=""/>
    <constraint field="map_label" desc="" exp=""/>
    <constraint field="category" desc="" exp=""/>
    <constraint field="group_name" desc="" exp=""/>
    <constraint field="osm_url" desc="" exp=""/>
    <constraint field="snapshot" desc="" exp=""/>
    <constraint field="inside_osm_campus" desc="" exp=""/>
    <constraint field="tags_json" desc="" exp=""/>
    <constraint field="building" desc="" exp=""/>
    <constraint field="amenity" desc="" exp=""/>
    <constraint field="highway" desc="" exp=""/>
    <constraint field="surface" desc="" exp=""/>
    <constraint field="access" desc="" exp=""/>
    <constraint field="operator" desc="" exp=""/>
    <constraint field="religion" desc="" exp=""/>
    <constraint field="leisure" desc="" exp=""/>
    <constraint field="natural" desc="" exp=""/>
    <constraint field="landuse" desc="" exp=""/>
    <constraint field="waterway" desc="" exp=""/>
    <constraint field="tourism" desc="" exp=""/>
    <constraint field="office" desc="" exp=""/>
    <constraint field="shop" desc="" exp=""/>
    <constraint field="building_levels" desc="" exp=""/>
    <constraint field="area_m2" desc="" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>coalesce(nullif("name",''),"category")</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>

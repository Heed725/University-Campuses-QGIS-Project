# Ardhi University — campus map

## Open in QGIS

1. Extract this ZIP into a normal folder.
2. Open **Ardhi_University.qgz** for the full mapped campus.
3. Open **Ardhi_Campus_Detail.qgz** for a closer view of the teaching and hostel area.

Use QGIS 3.34 or newer, including QGIS 3.40. Keep the `data` folder beside both projects. The packaged vector map works offline; no plugin is needed.

## Included

- OpenStreetMap campus boundary: **way 364739419**.
- **165 building footprints**, grouped into academic, housing, commercial/services and other buildings.
- **55 road/path features** and **34 facility point records**.
- **7 mapped vegetation polygons**, **2 sports polygons** and **32 stream/drainage features**.
- **1 gate/entrance record** and **3 bus-stop/transport point records** on or near the outline.
- Editable GeoPackage and EPSG:4326 GeoJSON copies.
- Reusable QGIS `.qml` styles and a searchable facilities CSV.
- Overview and detail A3 map layouts, with north arrows, scale bars, legends and source notes.
- Map previews in `maps/`.
- Optional online OpenStreetMap basemap.

The campus polygon measures approximately **85.16 hectares** in UTM zone 37S. This measures the mapped OSM polygon, not an independently confirmed university estate.

## Use and edit

- Tick layers to show/hide them. Double-click a layer → **Symbology** to change colours.
- Zoom in to read named departments and buildings. QGIS suppresses colliding labels. Original names are retained; map labels can be changed separately in `map_label`.
- Open the facilities attribute table to filter `name`, `category` or `group_name`; full names and direct source links are also in `Facilities.csv`.
- Use Identify Features to inspect a mapped object. Original OSM tags are in `tags_json`.
- Open **Project → Layouts** and choose either the overview or teaching/hostel map to export a PDF or PNG.
- Expand BASEMAP and tick OpenStreetMap for online tiles. Internet is required for this layer only; hide overlying vector layers if desired.

`data/ardhi_university.gpkg` is in **EPSG:32737 — WGS 84 / UTM zone 37S**. `area_m2` and `length_m` use square metres and metres. GeoJSON copies are in **EPSG:4326**. All project data paths are relative; move the entire extracted folder together.

## Source and limitations

Both boundary and campus features were downloaded from the **OpenStreetMap API on 11 October 2026**. No older UDSM or Chuo Kikuu extract is used for this campus dataset.

The outline is an OSM university map feature, not a cadastral survey or confirmed property boundary. Buildings are included by interior representative point; boundary-edge footprints can extend beyond the outline. Roads, drainage, vegetation and sports polygons are clipped to the mapped campus polygon. Area facilities are represented by interior points.

Gates and transport points are included inside or approximately 17 metres from the outline, using a 0.00015-degree geographic tolerance. `inside_osm_campus` indicates whether a representative point falls within the polygon; it does not establish ownership or affiliation.

Housing classification recognizes mapped hostels even where the generic `building` tag says `school`. Feature counts describe OSM records, not an official asset inventory. Duplicate records, unnamed objects and mapping gaps can exist. Opposite-side bus stops can be separate records. Campus names and spelling are preserved from OSM, including any source spelling mistakes.

The map does not include a DEM, flood assessment or routing. It is an independent map, not an official university publication.

## Attribution

Geographic data **© OpenStreetMap contributors**, licensed under **ODbL 1.0**. Adapted geographic layers retain that licence.

- https://www.openstreetmap.org/way/364739419
- https://www.openstreetmap.org/copyright
- https://opendatacommons.org/licenses/odbl/1-0/
- https://www.aru.ac.tz/
